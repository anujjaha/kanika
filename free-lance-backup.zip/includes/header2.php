<div class="main-header1">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
          <div class="logo">
            <label>Your</label>
            <span>Logo</span> </div>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
          <nav class="navbar navbar-inverse" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
              <ul class="nav navbar-nav">
                <li> <a class="active" href="show-job-post.php">Add New Job Post</a> </li>
                <li> <a class="active" href="#"> Buy Token </a> </li>
                <li><a href="#">Notification <span class="badge">5</span></a></li>
              </ul>
            </div>
            <!-- /.navbar-collapse -->
          </nav>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 col-lg-offset-1 col-md-offset-1 col-sm-offset-1  text-right">
          <div class="profile">
            <ul>
              <li><img  class="img-rounded" src="images/profile1.png" alt="profile_icon"/></li>
              <li><a href="">Profile</a>
                <ul class="hides">
                  <li><a href="#">Edit Profile</a></li>
                  <li><a href="#">Log out</a></li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
        
        
        
      </div>
    </div>
  </div>
</div>

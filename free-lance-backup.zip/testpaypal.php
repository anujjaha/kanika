<form method="post" action="https://www.sandbox.paypal.com/cgi-bin/webscr" id="paypal" name="paypal">
  <input type="hidden" value="_xclick" name="cmd">
  <input type="hidden" value="chhavikamboj7597@gmail.com" name="business">
  <!-- <input type="hidden" name="undefined_quantity" value="1" /> -->
  <input type="hidden" value="Departed Classmate Tribute Shop" name="item_name">
  <input type="text" value="2" name="item_number" id="item_number">
  <input type="text" value="2" name="amount" id="amount">
  <input type="hidden" value="USD" name="currency_code">
  <input type="hidden" value="http://www.genext-solutions.com/classmates/index.php/egifts/success" name="cancel_return">
<input type="hidden" value="http://www.genext-solutions.com/classmates/index.php/egifts/success" name="return">
<input type="hidden" value="http://www.genext-solutions.com/classmates/index.php/egifts/success" name="return">
  <input type="hidden" value="2" name="rm">      
 <!--input type="image" alt="" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif" onmouseover="this.style.cursor='pointer';" /-->

  
</form>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	document.paypal.submit();
	});
/*function submitform()
{
    
	
}*/
//window.onload = submitform;

//$(window).load(function() {
 //$(".loader").html("<img src='images/loading.gif'>");
 //document.frmProdPaypal.submit();
// window.onload = submitform();
//})
</script>
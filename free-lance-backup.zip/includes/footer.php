<footer>
  <div class="container">
    <div class="row">
       <div class="col-md-12 text-center">
       <div class="main-footer">
        <label>Follow us</label>
        </div>
      </div>
      <div class="col-lg-12 text-center">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="navigation">
             <ul>
          <li> <a class="  fa fa-facebook" href="http://facebook.com/"> </a> </li>
          <li> <a class=" twitter fa fa-twitter" href="http://twitter.com/"> </a> </li>
          <li> <a class=" fa fa-linkedin" href="https://www.linkedin.com/"> </a> </li>
          <li> <a class=" fa fa-pinterest" href="http://pinterest.com/"> </a> </li>
          <li> <a class=" fa fa-google-plus" href="http://plus.google.com/"> </a> </li>
        </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>
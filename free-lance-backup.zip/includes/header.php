<div class="main-header">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
          <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <div class="logo">
              <label>Your</label>
              <span>Logo</span> </div>
          </div>
           <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <nav class="navbar navbar-inverse" role="navigation">
              <!-- Brand and toggle get grouped for better mobile display -->
              <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
              </div>
              <!-- Collect the nav links, forms, and other content for toggling -->
              <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                 <li> <a class="active" href="#">BROWSE</a> </li>
                  <li> <a class="active" href="#">FIND JOBS</a> </li>
                  <li> <a href="#">HOW DOES IT WORKS</a> </li>
                </ul>
              </div>
              <!-- /.navbar-collapse -->
            </nav>
          </div>
           <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 text-right">
           <div class="sign">
          <a href="login.php"><button type="button" class="signin">Sign In</button></a>
           <a href="registration.php"><button type="button" class="signin">Join Now</button></a>
            </div>
      </div>
    </div>
  </div>
</div>
</div>
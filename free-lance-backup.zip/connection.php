<?php 
$con=mysql_connect("localhost","rrtechn1_freelau","freelau@123");
$database=mysql_select_db("rrtechn1_freelanewdb",$con);

//define('base_url', 'http://localhost/freelance/');
?>
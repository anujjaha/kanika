<?php
$con=mysql_connect("localhost","rrtechn1_freelau","freelau@123","rrtechn1_freelanewdb") or die("connection not eastablished");
$database=mysql_select_db("rrtechn1_freelanewdb",$con) or die("database not connected");
?>
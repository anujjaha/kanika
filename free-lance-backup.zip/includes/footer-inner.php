
<div class="main-footer">
	
  <div class="container">
    <div class="row">
	<div class="col-md-12 freefoot"> 
		
		<div class="col-md-2"> 
			<h4>Network</h4>
			<ul>
				<li><a href="#">Projects</a></li>
				<li><a href="#">Contests</a></li>
				<li><a href="#">Sitemap</a></li>
				<li><a href="#">Projects Directory</a></li>
				<li><a href="#">User Directory</a></li>
				<li><a href="#">Freelancer Local</a></li>
				<li><a href="#">Services</a></li>
				<li><a href="#">Escrow</a></li>
				<li><a href="#">Warrior Forum</a></li>
				<li><a href="#">Freemarket</a></li>
			</ul>
		</div>
		<div class="col-md-2"> 
			<h4>About</h4>
			<ul>
				<li><a href="#">About us</a></li>
				<li><a href="#">How it Works</a></li>
				<li><a href="#">Team</a></li>
				<li><a href="#">Mobile App</a></li>
				<li><a href="#">Desktop App</a></li>
				<li><a href="#">Security</a></li>
				<li><a href="#">Report Bug</a></li>
				<li><a href="#">Fees & Charges</a></li>
				<li><a href="#">Investor</a></li>
				<li><a href="#">Quotes</a></li>
			</ul>
		</div>
		<div class="col-md-2"> 
			<h4>Press</h4>
			<ul>
				<li><a href="#">In the News</a></li>
				<li><a href="#">Press Releases</a></li>
				<li><a href="#">Awards</a></li>
				<li><a href="#">Testimonials</a></li>
				<li><a href="#">Timeline</a></li>
			</ul>
		</div>
		<div class="col-md-2"> 
			<h4>Get in Touch</h4>
			<ul>
				<li><a href="#">Get Support</a></li>
				<li><a href="#">Advertise with Us</a></li>
				<li><a href="#">Careers</a></li>
				<li><a href="#">Community</a></li>
				<li><a href="#">Affiliate Program</a></li>
				<li><a href="#">Merchandise</a></li>
				<li><a href="#">Contact Us</a></li>
			</ul>

		</div>
		<div class="col-md-4 text-center"> 
			
		</div>
	</div>	
	</div>
	
	<div class="row">
      <div class="col-md-12 text-center "> 
      <label>Follow us</label>
      </div>
      <div class="col-md-4"></div>
       
      <div class="col-md-4">
      
<ul>
<li>
<a class="fa fa-facebook" href="http://facebook.com/"> </a>
</li>
<li>
<a class=" twitter fa fa-twitter" href="http://twitter.com/"> </a>
</li>
<li>
<a class=" fa fa-linkedin" href="https://www.linkedin.com/"> </a>
</li>
<li>
<a class=" fa fa-pinterest" href="http://pinterest.com/"> </a>
</li>
<li>
<a class=" fa fa-google-plus" href="http://plus.google.com/"> </a>
</li>
</ul>



</div>
<div class="col-md-4"></div>
      
      
      </div>
    </div>
  </div>
</div>
